// 📁 src/features/tarifs/EditTarif.js
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { updateTarif, fetchTarifs } from './tarifsSlice';
import { useParams, useNavigate } from 'react-router-dom';

function EditTarif() {
  const { id } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { tarifs } = useSelector((state) => state.tarifs);
  const tarif = tarifs.find((t) => t.id_Tarif === parseInt(id));
  const [form, setForm] = useState({ nom: '', prix: '', description: '' });

  useEffect(() => {
    if (!tarif) {
      dispatch(fetchTarifs());
    } else {
      setForm({
        nom: tarif.nom,
        prix: tarif.prix,
        description: tarif.description || ''
      });
    }
  }, [tarif, dispatch]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(updateTarif({
      id,
      data: {
        nom: form.nom,
        prix: parseFloat(form.prix),
        description: form.description || null
      }
    }));
    navigate('/tarifs');
  };

  if (!tarif) return <p>⏳ تحميل البيانات...</p>;

  return (
    <div>
      <h2>✏️ تعديل التعريف</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>اسم التعريف:</label>
          <input type="text" name="nom" value={form.nom} onChange={handleChange} required />
        </div>
        <div>
          <label>السعر:</label>
          <input type="number" name="prix" value={form.prix} onChange={handleChange} required />
        </div>
        <div>
          <label>الوصف:</label>
          <input type="text" name="description" value={form.description} onChange={handleChange} />
        </div>
        <button type="submit">✅ حفظ التعديلات</button>
      </form>
    </div>
  );
}

export default EditTarif;