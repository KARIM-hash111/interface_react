// 📁 src/features/tarifs/TarifList.js
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchTarifs, deleteTarif } from './tarifsSlice';
import { Link } from 'react-router-dom';

function TarifList() {
  const dispatch = useDispatch();
  const { tarifs, loading, error } = useSelector((state) => state.tarifs);

  useEffect(() => {
    dispatch(fetchTarifs());
  }, [dispatch]);

  const handleDelete = (id) => {
    if (window.confirm("هل أنت متأكد أنك تريد حذف هذا التعريف؟")) {
      dispatch(deleteTarif(id));
    }
  };

  if (loading) return <p>جاري التحميل...</p>;
  if (error) return <p>حدث خطأ: {error}</p>;

  return (
    <div>
      <h2>💸 قائمة التعريفات</h2>
      <Link to="/tarifs/add">➕ إضافة تعريف</Link>
      <ul>
        {tarifs.map((tarif) => (
          <li key={tarif.id_Tarif}>
            💰 {tarif.nom} - {tarif.prix} درهم - {tarif.description || 'بدون وصف'}
            <Link to={`/tarifs/edit/${tarif.id_Tarif}`}> ✏️ تعديل</Link>
            <button onClick={() => handleDelete(tarif.id_Tarif)}>🗑 حذف</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default TarifList;