// 📁 src/features/tarifs/AddTarif.js
import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addTarif } from './tarifsSlice';
import { useNavigate } from 'react-router-dom';

function AddTarif() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [form, setForm] = useState({ nom: '', prix: '', description: '' });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(addTarif({
      nom: form.nom,
      prix: parseFloat(form.prix),
      description: form.description || null
    }));
    navigate('/tarifs');
  };

  return (
    <div>
      <h2>➕ إضافة تعريف جديد</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>اسم التعريف:</label>
          <input type="text" name="nom" value={form.nom} onChange={handleChange} required />
        </div>
        <div>
          <label>السعر (درهم):</label>
          <input type="number" name="prix" value={form.prix} onChange={handleChange} required />
        </div>
        <div>
          <label>الوصف (اختياري):</label>
          <input type="text" name="description" value={form.description} onChange={handleChange} />
        </div>
        <button type="submit">💾 حفظ</button>
      </form>
    </div>
  );
}

export default AddTarif;