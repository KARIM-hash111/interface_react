// 📁 src/features/reservations/AddReservation.js
import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addReservation } from './reservationsSlice';
import { useNavigate } from 'react-router-dom';

function AddReservation() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [form, setForm] = useState({
    id_Client: '',
    id_Chambre: '',
    date_debut: '',
    date_fin: ''
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(addReservation(form));
    navigate('/reservations');
  };

  return (
    <div>
      <h2>Add New Reservation</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Client ID:</label>
          <input type="number" name="id_Client" value={form.id_Client} onChange={handleChange} required />
        </div>
        <div>
          <label>Room ID:</label>
          <input type="number" name="id_Chambre" value={form.id_Chambre} onChange={handleChange} required />
        </div>
        <div>
          <label>Start Date:</label>
          <input type="date" name="date_debut" value={form.date_debut} onChange={handleChange} required />
        </div>
        <div>
          <label>End Date:</label>
          <input type="date" name="date_fin" value={form.date_fin} onChange={handleChange} required />
        </div>
        <button type="submit">Save</button>
      </form>
    </div>
  );
}

export default AddReservation;