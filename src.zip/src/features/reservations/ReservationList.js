// 📁 src/features/reservations/ReservationList.js
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchReservations, deleteReservation } from './reservationsSlice';
import { Link } from 'react-router-dom';

function ReservationList() {
  const dispatch = useDispatch();
  const { reservations, loading, error } = useSelector((state) => state.reservations);

  useEffect(() => {
    dispatch(fetchReservations());
  }, [dispatch]);

  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this reservation?")) {
      dispatch(deleteReservation(id));
    }
  };

  if (loading) return <p>Loading reservations...</p>;
  if (error) return <p>Error: {error}</p>;

  return (
    <div>
      <h2>📋 Reservations List</h2>
      <Link to="/reservations/add">➕ Add Reservation</Link>
      <ul>
        {reservations.map((res) => (
          <li key={res.id}>
            Client: {res.id_Client} | Room: {res.id_Chambre} | From: {res.date_debut} To: {res.date_fin}
            <Link to={`/reservations/edit/${res.id}`}> ✏️ Edit</Link>
            <button onClick={() => handleDelete(res.id)}>🗑 Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default ReservationList;