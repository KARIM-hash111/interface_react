// 📁 src/features/chambreTarifs/EditChambreTarif.js
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { updateChambreTarif, fetchChambreTarifs } from './chambreTarifsSlice';
import { useParams, useNavigate } from 'react-router-dom';

function EditChambreTarif() {
  const { id } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { chambreTarifs } = useSelector((state) => state.chambreTarifs);
  const selected = chambreTarifs.find((item) => item.id === parseInt(id));

  const [form, setForm] = useState({
    id_Chambre: '',
    id_Tarif: '',
    date_debut: '',
    date_fin: ''
  });

  useEffect(() => {
    if (!selected) {
      dispatch(fetchChambreTarifs());
    } else {
      setForm({ ...selected });
    }
  }, [selected, dispatch]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(updateChambreTarif({ id, data: form }));
    navigate('/chambre-tarifs');
  };

  if (!selected) return <p>جاري تحميل البيانات...</p>;

  return (
    <div>
      <h2>✏️ تعديل الربط</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>معرف الغرفة:</label>
          <input type="number" name="id_Chambre" value={form.id_Chambre} onChange={handleChange} required />
        </div>
        <div>
          <label>معرف التعريفة:</label>
          <input type="number" name="id_Tarif" value={form.id_Tarif} onChange={handleChange} required />
        </div>
        <div>
          <label>تاريخ البداية:</label>
          <input type="date" name="date_debut" value={form.date_debut} onChange={handleChange} required />
        </div>
        <div>
          <label>تاريخ النهاية:</label>
          <input type="date" name="date_fin" value={form.date_fin} onChange={handleChange} required />
        </div>
        <button type="submit">✅ حفظ التعديلات</button>
      </form>
    </div>
  );
}

export default EditChambreTarif;