// 📁 src/features/chambreTarifs/AddChambreTarif.js
import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addChambreTarif } from './chambreTarifsSlice';
import { useNavigate } from 'react-router-dom';

function AddChambreTarif() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [form, setForm] = useState({
    id_Chambre: '',
    id_Tarif: '',
    date_debut: '',
    date_fin: ''
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(addChambreTarif(form));
    navigate('/chambre-tarifs');
  };

  return (
    <div>
      <h2>➕ إضافة ربط جديد</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>معرف الغرفة:</label>
          <input type="number" name="id_Chambre" value={form.id_Chambre} onChange={handleChange} required />
        </div>
        <div>
          <label>معرف التعريفة:</label>
          <input type="number" name="id_Tarif" value={form.id_Tarif} onChange={handleChange} required />
        </div>
        <div>
          <label>تاريخ البداية:</label>
          <input type="date" name="date_debut" value={form.date_debut} onChange={handleChange} required />
        </div>
        <div>
          <label>تاريخ النهاية:</label>
          <input type="date" name="date_fin" value={form.date_fin} onChange={handleChange} required />
        </div>
        <button type="submit">💾 حفظ</button>
      </form>
    </div>
  );
}

export default AddChambreTarif;