// 📁 src/features/chambreTarifs/ChambreTarifList.js
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchChambreTarifs, deleteChambreTarif } from './chambreTarifsSlice';
import { Link } from 'react-router-dom';

function ChambreTarifList() {
  const dispatch = useDispatch();
  const { chambreTarifs, loading, error } = useSelector((state) => state.chambreTarifs);

  useEffect(() => {
    dispatch(fetchChambreTarifs());
  }, [dispatch]);

  const handleDelete = (id) => {
    if (window.confirm("هل تريد حذف هذا الربط؟")) {
      dispatch(deleteChambreTarif(id));
    }
  };

  if (loading) return <p>تحميل...</p>;
  if (error) return <p>خطأ: {error}</p>;

  return (
    <div>
      <h2>🔗 لائحة ربط الغرف بالتعريفات</h2>
      <Link to="/chambre-tarifs/add">➕ إضافة ربط</Link>
      <ul>
        {chambreTarifs.map((item) => (
          <li key={item.id}>
            🛏 غرفة: {item.id_Chambre} | 💰 تعريف: {item.id_Tarif} | 📅 من: {item.date_debut} إلى: {item.date_fin}
            <Link to={`/chambre-tarifs/edit/${item.id}`}> ✏️ تعديل</Link>
            <button onClick={() => handleDelete(item.id)}>🗑 حذف</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default ChambreTarifList;